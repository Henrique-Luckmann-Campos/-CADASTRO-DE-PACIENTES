package senac.api.senac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SenacApplicationTests {

	@Test
	void contextLoads() {
	}

}
